import os, requests
from flask import Flask, request, jsonify, send_from_directory
app=Flask(__name__,static_folder="static")
@app.get("/")
def home(): return send_from_directory("static","index.html")
@app.post("/api/notify")
def notify():
    username=str((request.get_json(silent=True) or {}).get("username","")).strip()
    if not username or len(username)>30: return jsonify(ok=False,error="Введите корректный ник Roblox."),400
    token=os.getenv("TELEGRAM_BOT_TOKEN",""); chat=os.getenv("TELEGRAM_CHAT_ID","")
    if token and chat:
        try:
            r=requests.post(f"https://api.telegram.org/bot{token}/sendMessage",json={"chat_id":chat,"text":f"Новый посетитель Roblox Corner. Ник: {username}"},timeout=10)
            r.raise_for_status()
        except requests.RequestException: return jsonify(ok=False,error="Ошибка Telegram. Проверь настройки бота."),502
    return jsonify(ok=True)
if __name__=="__main__": app.run(host="127.0.0.1",port=5000)
